from django.apps import AppConfig


class SuserConfig(AppConfig):
    name = 'SUser'
